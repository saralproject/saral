# typing_test
> A simple javascript-based typing test.

## Playing the game

The game is available [here](https://lukeathedev.github.io/typing_test/).
